const questions = [
  {
    q: "كسر الروابط الموجودة في جزيئات المواد المتفاعلة وتكوين روابط جديدة في جزيئات المواد الناتجة يسمى:",
    options: ["الانحلال الحراري", "التفاعل الكيميائي", "النشاط الكيميائي", "قانون بقاء المادة"],
    answer: 1,
    explain: "لأن التفاعل الكيميائي ينتج عنه مواد جديدة نتيجة إعادة ترتيب الذرات وتكوين روابط جديدة."
  },
  {
    q: "أي مما يلي يدل على حدوث تفاعل كيميائي؟",
    options: ["تغير شكل الجسم فقط", "تكوين مادة جديدة", "تقطيع المادة", "تغيير مكان المادة"],
    answer: 1,
    explain: "أهم ما يميز التفاعل الكيميائي تكوين مادة أو مواد جديدة لها خواص مختلفة."
  },
  {
    q: "في التفاعل الكيميائي، المواد الموجودة قبل حدوث التفاعل تسمى:",
    options: ["النواتج", "المتفاعلات", "العوامل الحفازة", "الرواسب"],
    answer: 1,
    explain: "المتفاعلات هي المواد التي تدخل التفاعل وتتحول إلى نواتج."
  },
  {
    q: "المواد التي تتكون نتيجة التفاعل الكيميائي تسمى:",
    options: ["المتفاعلات", "النواتج", "العناصر", "المذيبات"],
    answer: 1,
    explain: "النواتج هي المواد الجديدة التي تتكون بعد حدوث التفاعل."
  },
  {
    q: "أي من الآتي مثال على تغير كيميائي؟",
    options: ["انصهار الثلج", "تبخر الماء", "صدأ الحديد", "تكسير الزجاج"],
    answer: 2,
    explain: "صدأ الحديد ينتج عنه مادة جديدة هي أكسيد الحديد."
  },
  {
    q: "طبقا لقانون بقاء المادة أثناء التفاعل الكيميائي:",
    options: ["تختفي الذرات", "تتكون الذرات من لا شيء", "لا تفنى المادة ولا تستحدث من العدم", "تتغير الذرات إلى طاقة فقط"],
    answer: 2,
    explain: "قانون بقاء المادة ينص على أن المادة لا تفنى ولا تستحدث من العدم، وإنما يعاد ترتيبها."
  },
  {
    q: "عند ملاحظة تصاعد فقاعات غاز عند خلط مادتين، فقد يكون ذلك دليلا على:",
    options: ["حدوث تفاعل كيميائي", "تغير الحالة فقط دائما", "انخفاض الكتلة", "عدم حدوث أي تغير"],
    answer: 0,
    explain: "تصاعد غاز من العلامات التي قد تشير إلى حدوث تفاعل كيميائي."
  },
  {
    q: "التفاعل الذي يحدث فيه اتحاد مادتين أو أكثر لتكوين مادة واحدة يسمى تفاعل:",
    options: ["اتحاد", "تحلل", "إحلال", "تعادل"],
    answer: 0,
    explain: "تفاعل الاتحاد يجمع مادتين أو أكثر لتكوين ناتج واحد."
  },
  {
    q: "التفاعل الذي تتحلل فيه مادة واحدة إلى مادتين أو أكثر يسمى تفاعل:",
    options: ["اتحاد", "تحلل", "احتراق فقط", "إحلال مزدوج"],
    answer: 1,
    explain: "في تفاعل التحلل تتحول مادة واحدة إلى مادتين أو أكثر."
  },
  {
    q: "ما الذي يحدث للذرات أثناء التفاعل الكيميائي؟",
    options: ["تختفي تماما", "تتحول إلى ذرات مختلفة دائما", "يعاد ترتيبها لتكوين مواد جديدة", "تتوقف عن الحركة"],
    answer: 2,
    explain: "الذرات لا تختفي، وإنما يعاد ترتيبها وتكوين روابط مختلفة بينها."
  }
];

let current = 0;
let score = 0;
let correct = 0;
let studentName = "";

const startScreen = document.getElementById("startScreen");
const quizScreen = document.getElementById("quizScreen");
const resultScreen = document.getElementById("resultScreen");
const nameInput = document.getElementById("studentName");
const startBtn = document.getElementById("startBtn");
const nextBtn = document.getElementById("nextBtn");
const restartBtn = document.getElementById("restartBtn");
const questionText = document.getElementById("questionText");
const answers = document.getElementById("answers");
const feedback = document.getElementById("feedback");
const scoreEl = document.getElementById("score");
const questionNumber = document.getElementById("questionNumber");
const progressBar = document.getElementById("progressBar");

startBtn.addEventListener("click", startQuiz);
nextBtn.addEventListener("click", nextQuestion);
restartBtn.addEventListener("click", () => {
  resultScreen.classList.add("hidden");
  startScreen.classList.remove("hidden");
  nameInput.value = studentName;
});

nameInput.addEventListener("keydown", e => {
  if (e.key === "Enter") startQuiz();
});

function startQuiz() {
  studentName = nameInput.value.trim();

  if (!studentName) {
    nameInput.focus();
    nameInput.style.borderColor = "#e45b5b";
    setTimeout(() => nameInput.style.borderColor = "", 700);
    return;
  }

  current = 0;
  score = 0;
  correct = 0;

  startScreen.classList.add("hidden");
  resultScreen.classList.add("hidden");
  quizScreen.classList.remove("hidden");

  showQuestion();
}

function showQuestion() {
  const item = questions[current];

  questionNumber.textContent = `السؤال ${current + 1} من ${questions.length}`;
  scoreEl.textContent = `الدرجة: ${score}`;
  progressBar.style.width = `${((current + 1) / questions.length) * 100}%`;

  questionText.textContent = item.q;
  answers.innerHTML = "";
  feedback.className = "feedback hidden";
  feedback.textContent = "";
  nextBtn.classList.add("hidden");

  item.options.forEach((option, index) => {
    const btn = document.createElement("button");
    btn.className = "answer";
    btn.textContent = `${String.fromCharCode(1571 + index)}) ${option}`;
    btn.addEventListener("click", () => chooseAnswer(index, btn));
    answers.appendChild(btn);
  });
}

function chooseAnswer(selected, selectedBtn) {
  const item = questions[current];
  const allButtons = [...answers.children];

  allButtons.forEach(btn => {
    btn.classList.add("disabled");
    btn.disabled = true;
  });

  if (selected === item.answer) {
    selectedBtn.classList.add("correct");
    score += 10;
    correct++;
    feedback.textContent = "✅ إجابة صحيحة! +10 درجات";
    feedback.className = "feedback good";
  } else {
    selectedBtn.classList.add("wrong");
    allButtons[item.answer].classList.add("correct");
    feedback.textContent = `❌ إجابة غير صحيحة. ${item.explain}`;
    feedback.className = "feedback bad";
  }

  scoreEl.textContent = `الدرجة: ${score}`;
  nextBtn.textContent = current === questions.length - 1 ? "🏆 عرض النتيجة" : "السؤال التالي ➜";
  nextBtn.classList.remove("hidden");
}

function nextQuestion() {
  current++;

  if (current >= questions.length) {
    showResult();
    return;
  }

  showQuestion();
}

function showResult() {
  quizScreen.classList.add("hidden");
  resultScreen.classList.remove("hidden");

  document.getElementById("resultName").textContent = `الطالب: ${studentName}`;
  document.getElementById("finalScore").textContent = `${score} / 100`;
  document.getElementById("correctCount").textContent = `${correct} / ${questions.length}`;

  let grade = "";
  let message = "";

  if (score >= 90) {
    grade = "ممتاز 🌟";
    message = "مستوى رائع جدًا! كمل بنفس القوة 💪";
  } else if (score >= 80) {
    grade = "جيد جدًا 👏";
    message = "شغل ممتاز، أنت قريب جدًا من الدرجة النهائية!";
  } else if (score >= 65) {
    grade = "جيد 👍";
    message = "نتيجة كويسة، ومع شوية مراجعة هتكون أفضل.";
  } else if (score >= 50) {
    grade = "مقبول 🙂";
    message = "راجع الدرس مرة كمان وحاول تعيد الاختبار.";
  } else {
    grade = "يحتاج مراجعة 📚";
    message = "ولا يهمك! راجع التفاعلات الكيميائية وجرب مرة أخرى.";
  }

  document.getElementById("grade").textContent = grade;
  document.getElementById("resultMessage").textContent = message;
}
